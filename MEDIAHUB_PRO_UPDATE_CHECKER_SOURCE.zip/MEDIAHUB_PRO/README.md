# MEDIAHUB PRO — Android media player

Native Android Java project. Application ID: `com.mediahub.rebuilt`.

## Current source version
- Version name: `2.1`
- Version code: `3`
- Minimum SDK: 23
- Target SDK: 34
- Compile SDK: 35
- Android Gradle Plugin: 8.6.1 (JDK 17 / Gradle 8.7)

## Included functionality
- Music, video, photo, playlists, favourites and recent library screens.
- Background music playback service with media notification controls.
- Media discovery and folder selection for additional storage.
- Dark, premium-style dashboard.

## Update checker added in this source
- A manual **Check for app updates** item is available in Settings.
- The app also checks GitHub Releases at most once every 24 hours.
- It reads the latest published release from `sarahbanaah-jpg/MEDIAHUB-PRO`.
- If a newer release has an APK asset, the user can download it from the prompt.
- Android still requires the user to confirm installation. The app cannot silently install APK updates.
- For the checker to find an update, publish a GitHub Release with a version tag such as `v2.1` and attach the correctly signed APK asset.

## Important release/signing requirement
The APK used for an in-place update MUST have the same application ID and be signed with the exact same private signing key as the installed app. A debug APK or APK signed with a different key will not update an existing installation; Android may report “App not installed”. Never commit a plaintext keystore or passwords to the repository. Back up the signing key securely.

## Build a debug APK
1. Extract this ZIP.
2. Open the `MEDIAHUB_PRO` folder (the folder containing `settings.gradle`) in Android Studio or CodeAssist.
3. Sync Gradle and install requested Android SDK packages.
4. Run `:app:assembleDebug`.
5. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

The included GitHub Actions workflow builds and uploads a **debug** APK. It is for testing only and is not automatically suitable for updating a separately signed release.

## Not yet implemented / verified
- Embedded album-art extraction and rich notification artwork.
- A complete visual redesign of every screen and motion/animation polish.
- Advanced video PiP, subtitle and playback-speed controls.
- Full Bluetooth/headset integration and playback resumption after reboot.
- A verified signed release build and physical-device regression testing.

The Android build has not been run in this environment. Build and test it on an Android SDK-equipped machine or GitHub Actions before distributing it.
