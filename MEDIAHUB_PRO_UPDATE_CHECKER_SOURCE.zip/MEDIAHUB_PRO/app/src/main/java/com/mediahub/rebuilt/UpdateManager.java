package com.mediahub.rebuilt;

import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Checks the project's GitHub Releases page and downloads the APK asset.
 * Android still asks the user to confirm installation of sideloaded updates.
 */
public final class UpdateManager {
    private static final String RELEASE_API =
            "https://api.github.com/repos/sarahbanaah-jpg/MEDIAHUB-PRO/releases/latest";

    private UpdateManager() {}

    public static void checkIfDue(Context context) {
        long last = context.getSharedPreferences("updates", Context.MODE_PRIVATE)
                .getLong("last_check", 0L);
        long now = System.currentTimeMillis();
        if (now - last >= 24L * 60L * 60L * 1000L) {
            context.getSharedPreferences("updates", Context.MODE_PRIVATE)
                    .edit().putLong("last_check", now).apply();
            check(context);
        }
    }

    public static void check(Context context) {
        final Context app = context.getApplicationContext();
        Toast.makeText(context, "Checking for updates…", Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(RELEASE_API).openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(12000);
                connection.setRequestProperty("Accept", "application/vnd.github+json");
                connection.setRequestProperty("User-Agent", "MEDIAHUB-PRO-Android");
                int status = connection.getResponseCode();
                if (status != HttpURLConnection.HTTP_OK) {
                    throw new Exception(status == 404
                            ? "No published release is available yet."
                            : "GitHub returned error " + status + ".");
                }

                StringBuilder body = new StringBuilder();
                try (InputStream in = connection.getInputStream();
                     BufferedReader reader = new BufferedReader(new InputStreamReader(in))) {
                    String line;
                    while ((line = reader.readLine()) != null) body.append(line);
                }

                JSONObject release = new JSONObject(body.toString());
                String tag = release.optString("tag_name", "");
                String releaseName = release.optString("name", tag);
                String notes = release.optString("body", "A new version is available.");
                JSONArray assets = release.optJSONArray("assets");
                String apkUrl = null;
                if (assets != null) {
                    for (int i = 0; i < assets.length(); i++) {
                        JSONObject asset = assets.getJSONObject(i);
                        String name = asset.optString("name", "");
                        String url = asset.optString("browser_download_url", "");
                        if (name.toLowerCase().endsWith(".apk") && url.startsWith("https://")) {
                            apkUrl = url;
                            break;
                        }
                    }
                }

                PackageInfo installed = app.getPackageManager().getPackageInfo(app.getPackageName(), 0);
                String current = installed.versionName == null ? "0" : installed.versionName;
                int versionComparison = compareVersions(tag, current);
                String finalApkUrl = apkUrl;
                Handler handler = new Handler(Looper.getMainLooper());

                if (versionComparison <= 0) {
                    handler.post(() -> new AlertDialog.Builder(context)
                            .setTitle("You're up to date")
                            .setMessage("MEDIAHUB-PRO " + current + " is the latest available version.")
                            .setPositiveButton("OK", null).show());
                } else if (finalApkUrl == null) {
                    handler.post(() -> new AlertDialog.Builder(context)
                            .setTitle("Update found, APK missing")
                            .setMessage("Release " + releaseName + " exists, but it has no APK attached yet.")
                            .setPositiveButton("OK", null).show());
                } else {
                    String message = "Installed version: " + current + "\nNew version: "
                            + releaseName + "\n\n" + trim(notes, 700);
                    handler.post(() -> new AlertDialog.Builder(context)
                            .setTitle("MEDIAHUB-PRO update available")
                            .setMessage(message)
                            .setNegativeButton("Later", null)
                            .setPositiveButton("Download", (dialog, which) ->
                                    download(context, finalApkUrl, releaseName))
                            .show());
                }
            } catch (Exception e) {
                String message = e.getMessage() == null ? "Please try again later." : e.getMessage();
                new Handler(Looper.getMainLooper()).post(() ->
                        new AlertDialog.Builder(context)
                                .setTitle("Couldn't check for updates")
                                .setMessage(message + "\n\nCheck your internet connection and try again.")
                                .setPositiveButton("OK", null).show());
            } finally {
                if (connection != null) connection.disconnect();
            }
        }).start();
    }

    private static void download(Context context, String url, String version) {
        try {
            DownloadManager manager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle("MEDIAHUB-PRO " + version);
            request.setDescription("Downloading app update");
            request.setMimeType("application/vnd.android.package-archive");
            request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS,
                    "MEDIAHUB-PRO-update.apk");
            manager.enqueue(request);
            Toast.makeText(context,
                    "Download started. Open the completed download notification to install.",
                    Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(context, "Could not start the update download.", Toast.LENGTH_LONG).show();
        }
    }

    private static int compareVersions(String latest, String current) {
        try {
            String[] a = latest.replaceFirst("^[vV]", "").split("[.-]");
            String[] b = current.replaceFirst("^[vV]", "").split("[.-]");
            int count = Math.max(a.length, b.length);
            for (int i = 0; i < count; i++) {
                int x = i < a.length ? Integer.parseInt(a[i].replaceAll("[^0-9].*$", "")) : 0;
                int y = i < b.length ? Integer.parseInt(b[i].replaceAll("[^0-9].*$", "")) : 0;
                if (x != y) return Integer.compare(x, y);
            }
            return 0;
        } catch (Exception ignored) {
            return latest.compareToIgnoreCase(current);
        }
    }

    private static String trim(String value, int max) {
        if (value == null || value.trim().isEmpty()) return "A new version is available.";
        String clean = value.trim();
        return clean.length() <= max ? clean : clean.substring(0, max) + "…";
    }
}
