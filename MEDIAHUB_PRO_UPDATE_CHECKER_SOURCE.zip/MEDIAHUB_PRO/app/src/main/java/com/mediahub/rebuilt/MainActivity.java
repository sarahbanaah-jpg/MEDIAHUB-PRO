package com.mediahub.rebuilt;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_MEDIA = 42, REQ_TREE = 43;
    private TextView summary, storageStatus, nowTitle, nowArtist, nowPlay;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        summary=findViewById(R.id.summaryText); storageStatus=findViewById(R.id.storageStatus);
        nowTitle=findViewById(R.id.nowPlayingTitle);nowArtist=findViewById(R.id.nowPlayingArtist);nowPlay=findViewById(R.id.nowPlayingPlay);
        findViewById(R.id.nowPlayingOpen).setOnClickListener(v->{String uri=getSharedPreferences("now_playing",MODE_PRIVATE).getString("uri",null);if(uri!=null){Intent p=new Intent(this,PlayerActivity.class);p.putExtra("uri",uri);startActivity(p);}});
        nowPlay.setOnClickListener(v->{boolean wasPlaying=getSharedPreferences("now_playing",MODE_PRIVATE).getBoolean("playing",false);Intent p=new Intent(this,PlaybackService.class).setAction("TOGGLE");if(Build.VERSION.SDK_INT>=26)startForegroundService(p);else startService(p);nowPlay.setText(wasPlaying?"▶":"Ⅱ");});
        findViewById(R.id.musicButton).setOnClickListener(v -> openLibrary(LibraryActivity.KIND_MUSIC));
        findViewById(R.id.videoButton).setOnClickListener(v -> openLibrary(LibraryActivity.KIND_VIDEO));
        findViewById(R.id.photosButton).setOnClickListener(v -> openLibrary(LibraryActivity.KIND_PHOTO));
        findViewById(R.id.favouritesButton).setOnClickListener(v -> openSaved("favourites"));
        findViewById(R.id.recentButton).setOnClickListener(v -> openSaved("recent"));
        findViewById(R.id.equalizerButton).setOnClickListener(v -> startActivity(new Intent(this, EqualizerActivity.class)));
        findViewById(R.id.settingsButton).setOnClickListener(v -> showSettings());
        findViewById(R.id.searchButton).setOnClickListener(v -> openLibrary(LibraryActivity.KIND_MUSIC));
        findViewById(R.id.playlistsButton).setOnClickListener(v -> startActivity(new Intent(this, PlaylistsActivity.class)));
        findViewById(R.id.addStorageButton).setOnClickListener(v -> chooseStorageFolder());
        requestMediaPermissions(); updateStorageLabel(); refreshNowPlaying(); UpdateManager.checkIfDue(this);
    }
    private void requestMediaPermissions() {
        java.util.ArrayList<String> p=new java.util.ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS);
        if (Build.VERSION.SDK_INT >= 34) { p.add(Manifest.permission.READ_MEDIA_AUDIO); p.add(Manifest.permission.READ_MEDIA_VIDEO); p.add(Manifest.permission.READ_MEDIA_IMAGES); p.add("android.permission.READ_MEDIA_VISUAL_USER_SELECTED"); }
        else if (Build.VERSION.SDK_INT >= 33) { p.add(Manifest.permission.READ_MEDIA_AUDIO); p.add(Manifest.permission.READ_MEDIA_VIDEO); p.add(Manifest.permission.READ_MEDIA_IMAGES); }
        else p.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        java.util.ArrayList<String> missing=new java.util.ArrayList<>();
        for(String x:p) if(checkSelfPermission(x)!=PackageManager.PERMISSION_GRANTED) missing.add(x);
        if(!missing.isEmpty()) requestPermissions(missing.toArray(new String[0]),REQ_MEDIA); else updateSummary();
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){super.onRequestPermissionsResult(requestCode,permissions,results);if(requestCode==REQ_MEDIA)updateSummary();}
    private void updateSummary(){int a=MediaRepository.query(this,0).size(),v=MediaRepository.query(this,1).size(),p=MediaRepository.query(this,2).size();summary.setText(a+" songs   ·   "+v+" videos   ·   "+p+" photos indexed");}
    private void updateStorageLabel(){String u=getSharedPreferences("mediahub_storage",MODE_PRIVATE).getString("tree_uri",null);storageStatus.setText(u==null?"Internal storage · SD card not added":"Internal storage + SD card folder connected");}
    private void chooseStorageFolder(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,REQ_TREE);}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==REQ_TREE&&resultCode==RESULT_OK&&data!=null){Uri tree=data.getData();try{getContentResolver().takePersistableUriPermission(tree,data.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION);getSharedPreferences("mediahub_storage",MODE_PRIVATE).edit().putString("tree_uri",tree.toString()).apply();updateStorageLabel();updateSummary();Toast.makeText(this,"Folder connected. Its media is now included in your libraries.",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Could not keep access to that folder. Please select it again.",Toast.LENGTH_LONG).show();}}}
    public void navMusic(android.view.View v){openLibrary(LibraryActivity.KIND_MUSIC);}
    public void navPlaylists(android.view.View v){startActivity(new Intent(this,PlaylistsActivity.class));}
    public void navPhotos(android.view.View v){openLibrary(LibraryActivity.KIND_PHOTO);}
    public void navSettings(android.view.View v){showSettings();}
    private void refreshNowPlaying(){if(nowTitle==null)return;android.content.SharedPreferences p=getSharedPreferences("now_playing",MODE_PRIVATE);String uri=p.getString("uri",null);boolean playing=p.getBoolean("playing",false);findViewById(R.id.nowPlayingCard).setVisibility(uri==null?android.view.View.GONE:android.view.View.VISIBLE);if(uri!=null){nowTitle.setText(p.getString("title","Unknown track"));nowArtist.setText(p.getString("artist","Unknown artist"));nowPlay.setText(playing?"Ⅱ":"▶");}}
    private void openLibrary(int kind){Intent i=new Intent(this,LibraryActivity.class);i.putExtra("kind",kind);startActivity(i);}
    private void openSaved(String key){Intent i=new Intent(this,LibraryActivity.class);i.putExtra("kind",0);i.putExtra("saved",key);startActivity(i);}
    private void showSettings(){String[] choices={"Check for app updates","Add SD card / storage folder","Refresh media index","App information","Audio equalizer","Storage & permissions"};new android.app.AlertDialog.Builder(this).setTitle("Settings & storage").setItems(choices,(d,w)->{if(w==0)UpdateManager.check(this);else if(w==1)chooseStorageFolder();else if(w==2){updateSummary();Toast.makeText(this,"Media index refreshed.",Toast.LENGTH_SHORT).show();}else if(w==3){Intent i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()));startActivity(i);}else if(w==4)startActivity(new Intent(this,EqualizerActivity.class));else requestMediaPermissions();}).setNegativeButton("Close",null).show();}
    @Override protected void onResume(){super.onResume();if(summary!=null){updateSummary();updateStorageLabel();refreshNowPlaying();}}
}
