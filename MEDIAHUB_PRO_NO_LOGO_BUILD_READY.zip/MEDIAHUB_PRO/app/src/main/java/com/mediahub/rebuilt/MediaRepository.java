package com.mediahub.rebuilt;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Unified media index: MediaStore across mounted volumes plus any user-granted folder trees. */
public final class MediaRepository {
    private MediaRepository() {}
    public static List<MediaItem> query(Context context, int kind) {
        List<MediaItem> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        if (Build.VERSION.SDK_INT >= 29) {
            for (String volume : MediaStore.getExternalVolumeNames(context)) {
                Uri collection = collection(kind, volume);
                queryCollection(context, kind, collection, out, seen);
            }
        } else {
            queryCollection(context, kind, collection(kind, null), out, seen);
        }
        // SAF folder access is the reliable fallback for removable cards and custom folders.
        String tree = context.getSharedPreferences("mediahub_storage", Context.MODE_PRIVATE).getString("tree_uri", null);
        if (tree != null) {
            try { walkTree(context, Uri.parse(tree), DocumentsContract.getTreeDocumentId(Uri.parse(tree)), kind, out, seen, 0); }
            catch (Exception ignored) { }
        }
        return out;
    }
    private static Uri collection(int kind, String volume) {
        if (kind == LibraryActivity.KIND_MUSIC) return volume == null ? MediaStore.Audio.Media.EXTERNAL_CONTENT_URI : MediaStore.Audio.Media.getContentUri(volume);
        if (kind == LibraryActivity.KIND_VIDEO) return volume == null ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Video.Media.getContentUri(volume);
        return volume == null ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.getContentUri(volume);
    }
    private static void queryCollection(Context context, int kind, Uri collection, List<MediaItem> out, Set<String> seen) {
        String[] projection;
        String sort;
        if (kind == LibraryActivity.KIND_MUSIC) {
            projection = new String[]{MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.MIME_TYPE};
            sort = MediaStore.Audio.Media.DATE_ADDED + " DESC";
        } else if (kind == LibraryActivity.KIND_VIDEO) {
            projection = new String[]{MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE, MediaStore.Video.Media.DURATION, MediaStore.Video.Media.MIME_TYPE};
            sort = MediaStore.Video.Media.DATE_ADDED + " DESC";
        } else {
            projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.TITLE, MediaStore.Images.Media.MIME_TYPE};
            sort = MediaStore.Images.Media.DATE_ADDED + " DESC";
        }
        try (Cursor c = context.getContentResolver().query(collection, projection, null, null, sort)) {
            if (c == null) return;
            while (c.moveToNext()) {
                long id = c.getLong(0);
                String title = c.getString(1);
                String artist = kind == LibraryActivity.KIND_MUSIC ? c.getString(2) : "";
                long duration = kind == LibraryActivity.KIND_MUSIC || kind == LibraryActivity.KIND_VIDEO ? c.getLong(kind == LibraryActivity.KIND_MUSIC ? 3 : 2) : 0;
                String mime = c.getString(kind == LibraryActivity.KIND_MUSIC ? 4 : kind == LibraryActivity.KIND_VIDEO ? 3 : 2);
                Uri itemUri = Uri.withAppendedPath(collection, String.valueOf(id));
                if (seen.add(itemUri.toString())) out.add(new MediaItem(id, title == null ? "Untitled" : title, artist, itemUri, duration, mime));
            }
        } catch (SecurityException ignored) { } catch (RuntimeException ignored) { }
    }
    private static void walkTree(Context context, Uri tree, String parentId, int kind, List<MediaItem> out, Set<String> seen, int depth) {
        if (depth > 12 || out.size() > 10000) return;
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId);
        String[] cols = {DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE};
        try (Cursor c = context.getContentResolver().query(children, cols, null, null, null)) {
            if (c == null) return;
            while (c.moveToNext()) {
                String id = c.getString(0), name = c.getString(1), mime = c.getString(2);
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) { walkTree(context, tree, id, kind, out, seen, depth + 1); continue; }
                if (!matchesKind(name, mime, kind)) continue;
                Uri itemUri = DocumentsContract.buildDocumentUriUsingTree(tree, id);
                if (seen.add(itemUri.toString())) out.add(new MediaItem(id.hashCode(), name == null ? "Untitled" : name, "", itemUri, 0, mime));
            }
        } catch (Exception ignored) { }
    }
    private static boolean matchesKind(String name, String mime, int kind) {
        String m = mime == null ? "" : mime.toLowerCase();
        if (kind == LibraryActivity.KIND_MUSIC && m.startsWith("audio/")) return true;
        if (kind == LibraryActivity.KIND_VIDEO && m.startsWith("video/")) return true;
        if (kind == LibraryActivity.KIND_PHOTO && m.startsWith("image/")) return true;
        String n = name == null ? "" : name.toLowerCase();
        if (kind == LibraryActivity.KIND_MUSIC) return n.matches(".*\\.(mp3|m4a|aac|flac|wav|ogg|opus|wma|mid|midi)$");
        if (kind == LibraryActivity.KIND_VIDEO) return n.matches(".*\\.(mp4|mkv|3gp|webm|avi|mov|m4v|ts)$");
        return n.matches(".*\\.(jpg|jpeg|png|gif|webp|bmp|heic|heif|tif|tiff)$");
    }
}
