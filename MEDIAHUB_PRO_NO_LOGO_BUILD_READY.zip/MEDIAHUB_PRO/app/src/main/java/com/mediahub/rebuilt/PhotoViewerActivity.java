package com.mediahub.rebuilt;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;

public class PhotoViewerActivity extends Activity {
    private ScaleGestureDetector scale;
    private float zoom=1f;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_photo);
        ImageView image=findViewById(R.id.photoImage);
        String raw=getIntent().getStringExtra("uri");
        if(raw==null){finish();return;}
        try { image.setImageURI(Uri.parse(raw)); } catch(Exception e){Toast.makeText(this,"Unable to open image.",Toast.LENGTH_LONG).show();finish();}
        scale=new ScaleGestureDetector(this,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
            @Override public boolean onScale(ScaleGestureDetector d){zoom=Math.max(1f,Math.min(5f,zoom*d.getScaleFactor()));image.setScaleX(zoom);image.setScaleY(zoom);return true;}
        });
        image.setOnTouchListener((v,event)->{scale.onTouchEvent(event);return true;});
    }
}
