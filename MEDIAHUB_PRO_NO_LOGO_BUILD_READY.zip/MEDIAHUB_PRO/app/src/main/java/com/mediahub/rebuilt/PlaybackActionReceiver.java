package com.mediahub.rebuilt;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
public class PlaybackActionReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context context,Intent intent){Intent service=new Intent(context,PlaybackService.class).setAction(intent.getAction());if(Build.VERSION.SDK_INT>=26)context.startForegroundService(service);else context.startService(service);}
}
