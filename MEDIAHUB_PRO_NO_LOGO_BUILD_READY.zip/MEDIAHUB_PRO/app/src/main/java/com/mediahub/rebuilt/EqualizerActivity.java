package com.mediahub.rebuilt;

import android.app.Activity;
import android.media.audiofx.Equalizer;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Virtualizer;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class EqualizerActivity extends Activity {
    private Equalizer equalizer;
    private BassBoost bass;
    private Virtualizer virtualizer;
    private short[] original;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_equalizer);
        Spinner spinner=findViewById(R.id.presetSpinner);
        String[] presets={"Normal","Rock","Pop","Jazz","Classical"};
        spinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,presets));
        TextView status=findViewById(R.id.effectStatus);
        try {
            equalizer=new Equalizer(0,0); equalizer.setEnabled(true);
            bass=new BassBoost(0,0); bass.setEnabled(true);
            virtualizer=new Virtualizer(0,0); virtualizer.setEnabled(true);
            short count=equalizer.getNumberOfBands();
            original=new short[count];
            LinearLayout container=findViewById(R.id.bandContainer);
            for(short i=0;i<count;i++){
                final short band=i;
                original[i]=equalizer.getBandLevel(i);
                TextView label=new TextView(this); label.setText(equalizer.getCenterFreq(i)/1000+" Hz");
                label.setTextColor(0xFFFFFFFF); container.addView(label);
                SeekBar bar=new SeekBar(this); bar.setMax(equalizer.getBandLevelRange()[1]-equalizer.getBandLevelRange()[0]);
                bar.setProgress(original[i]-equalizer.getBandLevelRange()[0]); container.addView(bar);
                bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                    public void onProgressChanged(SeekBar s,int p,boolean user){if(user)try{equalizer.setBandLevel(band,(short)(p+equalizer.getBandLevelRange()[0]));}catch(Exception ignored){}}
                    public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
                });
            }
            spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
                public void onNothingSelected(android.widget.AdapterView<?> p){}
                public void onItemSelected(android.widget.AdapterView<?> p,android.view.View v,int pos,long id){
                    if(pos==0)return;
                    short n=equalizer.getNumberOfPresets();
                    for(short x=0;x<n;x++) if(equalizer.getPresetName(x).equalsIgnoreCase(presets[pos])) {equalizer.usePreset(x);break;}
                }
            });
            status.setText("Native equalizer enabled • "+count+" bands available");
        } catch(Exception e) {
            status.setText("Equalizer effects are not supported by this device or no audio session is active.");
            Toast.makeText(this,"Some audio effects are unavailable.",Toast.LENGTH_SHORT).show();
        }
    }
    @Override protected void onDestroy(){try{if(equalizer!=null)equalizer.release();if(bass!=null)bass.release();if(virtualizer!=null)virtualizer.release();}catch(Exception ignored){}super.onDestroy();}
}
