package com.mediahub.rebuilt;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import java.util.List;

public class PlaylistsActivity extends Activity {
    private List<String> names; private ArrayAdapter<String> adapter;
    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_playlists);
        ListView list=findViewById(R.id.playlistList); refresh(list);
        ((Button)findViewById(R.id.createPlaylist)).setOnClickListener(v->{
            EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Playlist name");
            new android.app.AlertDialog.Builder(this).setTitle("New playlist").setView(input)
                .setPositiveButton("Create",(d,w)->{String n=input.getText().toString().trim();if(!n.isEmpty()&&!LibraryStore.names(this).contains(n)){LibraryStore.createPlaylist(this,n);refresh(list);}else Toast.makeText(this,"Enter a unique playlist name.",Toast.LENGTH_SHORT).show();})
                .setNegativeButton("Cancel",null).show();
        });
        list.setOnItemClickListener((p,v,pos,id)->showActions(names.get(pos),list));
        list.setOnItemLongClickListener((p,v,pos,id)->{showActions(names.get(pos),list);return true;});
    }
    private void refresh(ListView list){names=LibraryStore.names(this);adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,names);list.setAdapter(adapter);}
    private void showActions(String name,ListView list){
        new android.app.AlertDialog.Builder(this).setTitle(name).setItems(new String[]{"Play playlist","View / remove tracks","Rename","Delete"},(d,w)->{
            if(w==0){List<String> items=LibraryStore.playlistItems(this,name);if(items.isEmpty()){Toast.makeText(this,"This playlist is empty.",Toast.LENGTH_SHORT).show();return;}
                android.content.Intent i=new android.content.Intent(this,PlayerActivity.class);i.putExtra("playlistUris",items.toArray(new String[0]));i.putExtra("uri",items.get(0));startActivity(i);
            } else if(w==1){showTracks(name);}
            else if(w==2){EditText input=new EditText(this);input.setText(name);new android.app.AlertDialog.Builder(this).setTitle("Rename playlist").setView(input).setPositiveButton("Save",(x,y)->{String n=input.getText().toString().trim();if(!n.isEmpty()&&!LibraryStore.names(this).contains(n))LibraryStore.renamePlaylist(this,name,n);else Toast.makeText(this,"Choose a unique name.",Toast.LENGTH_SHORT).show();refresh(list);}).setNegativeButton("Cancel",null).show();}
            else new android.app.AlertDialog.Builder(this).setMessage("Delete playlist '"+name+"'?").setPositiveButton("Delete",(x,y)->{LibraryStore.deletePlaylist(this,name);refresh(list);}).setNegativeButton("Cancel",null).show();
        }).show();
    }
    private void showTracks(String name){
        List<String> uris=LibraryStore.playlistItems(this,name);List<MediaItem> indexed=MediaRepository.query(this,LibraryActivity.KIND_MUSIC);java.util.ArrayList<MediaItem> tracks=new java.util.ArrayList<>();
        for(String u:uris)for(MediaItem m:indexed)if(m.uri.toString().equals(u)){tracks.add(m);break;}
        if(tracks.isEmpty()){Toast.makeText(this,"No available tracks in this playlist.",Toast.LENGTH_SHORT).show();return;}
        String[] labels=new String[tracks.size()];for(int i=0;i<tracks.size();i++)labels[i]=tracks.get(i).title;
        new android.app.AlertDialog.Builder(this).setTitle("Tracks · tap to remove").setItems(labels,(d,pos)->new android.app.AlertDialog.Builder(this).setMessage("Remove '"+tracks.get(pos).title+"' from this playlist?").setPositiveButton("Remove",(x,y)->showRemove(name,tracks.get(pos).uri.toString())).setNegativeButton("Cancel",null).show()).setNegativeButton("Close",null).show();
    }
    private void showRemove(String name,String uri){LibraryStore.removeFromPlaylist(this,name,uri);showTracks(name);}

}
