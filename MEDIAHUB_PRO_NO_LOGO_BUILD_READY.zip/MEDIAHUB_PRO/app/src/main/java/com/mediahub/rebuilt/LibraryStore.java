package com.mediahub.rebuilt;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class LibraryStore {
    private static final String PREF="mediahub_local_library";
    private LibraryStore(){}
    private static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    private static JSONArray read(Context c,String key){
        try{return new JSONArray(prefs(c).getString(key,"[]"));}catch(Exception e){return new JSONArray();}
    }
    private static void write(Context c,String key,JSONArray a){prefs(c).edit().putString(key,a.toString()).apply();}
    public static void addFavourite(Context c,MediaItem m){addUnique(c,"favourites",m);}
    public static void removeFavourite(Context c,String uri){remove(c,"favourites",uri);}
    public static boolean isFavourite(Context c,String uri){return contains(c,"favourites",uri);}
    public static void addRecent(Context c,MediaItem m){
        remove(c,"recent",m.uri.toString()); addUnique(c,"recent",m);
        JSONArray a=read(c,"recent"); while(a.length()>30)a.remove(a.length()-1); write(c,"recent",a);
    }
    public static List<String> names(Context c){
        JSONArray a=read(c,"playlists"); List<String> out=new ArrayList<>();
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null){String n=o.optString("name", "");if(!n.isEmpty())out.add(n);}} return out;
    }
    public static void createPlaylist(Context c,String name){
        JSONArray a=read(c,"playlists"); JSONObject o=new JSONObject();
        try{o.put("name",name);o.put("items",new JSONArray());a.put(o);}catch(Exception ignored){} write(c,"playlists",a);
    }
    public static void renamePlaylist(Context c,String oldName,String newName){
        JSONArray a=read(c,"playlists");
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&o.optString("name").equals(oldName))try{o.put("name",newName);}catch(Exception ignored){}}
        write(c,"playlists",a);
    }
    public static void deletePlaylist(Context c,String name){
        JSONArray a=read(c,"playlists"),b=new JSONArray();
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&!o.optString("name").equals(name))b.put(o);}
        write(c,"playlists",b);
    }
    public static void addToPlaylist(Context c,String name,MediaItem m){
        JSONArray a=read(c,"playlists");
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&o.optString("name").equals(name)){
            JSONArray items=o.optJSONArray("items");if(items==null)items=new JSONArray();
            boolean exists=false;for(int j=0;j<items.length();j++)if(m.uri.toString().equals(items.optString(j)))exists=true;
            if(!exists)items.put(m.uri.toString());try{o.put("items",items);}catch(Exception ignored){}
        }}
        write(c,"playlists",a);
    }
    public static void removeFromPlaylist(Context c,String name,String uri){
        JSONArray a=read(c,"playlists");
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&o.optString("name").equals(name)){
            JSONArray old=o.optJSONArray("items"),n=new JSONArray();if(old!=null)for(int j=0;j<old.length();j++)if(!uri.equals(old.optString(j)))n.put(old.optString(j));
            try{o.put("items",n);}catch(Exception ignored){}
        }}write(c,"playlists",a);
    }
    public static List<String> playlistItems(Context c,String name){
        JSONArray a=read(c,"playlists");List<String> out=new ArrayList<>();
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&o.optString("name").equals(name)){
            JSONArray x=o.optJSONArray("items");if(x!=null)for(int j=0;j<x.length();j++)out.add(x.optString(j));
        }}return out;
    }

    public static List<MediaItem> savedItems(Context c,String key){
        JSONArray a=read(c,key);List<MediaItem> out=new ArrayList<>();
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;try{String raw=o.optString("uri","");if(raw.isEmpty())continue;android.net.Uri u=android.net.Uri.parse(raw);String title=o.optString("title","Untitled"),artist=o.optString("artist","");String mime=c.getContentResolver().getType(u);out.add(new MediaItem(i,title,artist,u,0,mime));}catch(Exception ignored){}}
        return out;
    }
    private static void addUnique(Context c,String key,MediaItem m){
        JSONArray a=read(c,key);remove(c,key,m.uri.toString());a=read(c,key);JSONObject o=new JSONObject();
        try{o.put("uri",m.uri.toString());o.put("title",m.title);o.put("artist",m.artist);a.put(0,o);}catch(Exception ignored){}write(c,key,a);
    }
    private static boolean contains(Context c,String key,String uri){JSONArray a=read(c,key);for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&uri.equals(o.optString("uri")))return true;}return false;}
    private static void remove(Context c,String key,String uri){
        JSONArray a=read(c,key),b=new JSONArray();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&!uri.equals(o.optString("uri")))b.put(o);}write(c,key,b);
    }
}
