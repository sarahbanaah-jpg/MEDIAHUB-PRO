package com.mediahub.rebuilt;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import android.net.Uri;

public class PlayerActivity extends Activity {
    private TextView title,artist,elapsed,duration;
    private SeekBar seek;
    private final Handler handler=new Handler();
    private boolean dragging=false;
    private int index=0;
    private boolean shuffle=false;
    private int repeat=0;
    private boolean completionHandled=false;
    private final List<MediaItem> queue=new ArrayList<>();
    private final android.content.BroadcastReceiver trackReceiver=new android.content.BroadcastReceiver(){
        @Override public void onReceive(android.content.Context c,Intent i){String uri=i.getStringExtra("uri");for(int q=0;q<queue.size();q++)if(queue.get(q).uri.toString().equals(uri)){index=q;break;}title.setText(i.getStringExtra("title"));artist.setText(i.getStringExtra("artist"));completionHandled=false;}
    };
    private Runnable ticker=new Runnable(){public void run(){PlaybackService service=PlaybackService.instance;
        if(service!=null&&service.isPrepared()){int pos=service.getPlayer().getCurrentPosition(),dur=service.getPlayer().getDuration();
            if(!dragging){seek.setMax(Math.max(1,dur));seek.setProgress(pos);}elapsed.setText(fmt(pos));duration.setText(fmt(dur));
            
        }
        handler.postDelayed(this,500);
    }};
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);setContentView(R.layout.activity_player);
        title=findViewById(R.id.playerTitle);artist=findViewById(R.id.playerArtist);elapsed=findViewById(R.id.playerElapsed);duration=findViewById(R.id.playerDuration);seek=findViewById(R.id.playerSeek);
        String[] playlistUris=getIntent().getStringArrayExtra("playlistUris");
        List<MediaItem> indexed=MediaRepository.query(this,LibraryActivity.KIND_MUSIC);
        if(playlistUris!=null){for(String u:playlistUris)for(MediaItem m:indexed)if(m.uri.toString().equals(u)){queue.add(m);break;}}
        else queue.addAll(indexed);
        if(queue.isEmpty()){Toast.makeText(this,"No music found.",Toast.LENGTH_LONG).show();finish();return;}
        String wanted=getIntent().getStringExtra("uri");
        for(int i=0;i<queue.size();i++)if(queue.get(i).uri.toString().equals(wanted)){index=i;break;}
        String activeUri=getSharedPreferences("now_playing",MODE_PRIVATE).getString("uri",null);
        if(wanted!=null&&wanted.equals(activeUri)&&PlaybackService.instance!=null&&PlaybackService.instance.isPrepared()){
            title.setText(getSharedPreferences("now_playing",MODE_PRIVATE).getString("title","Now playing"));
            artist.setText(getSharedPreferences("now_playing",MODE_PRIVATE).getString("artist",""));
        }else playCurrent();
        ((Button)findViewById(R.id.playerToggle)).setOnClickListener(v->send("TOGGLE"));
        ((Button)findViewById(R.id.playerNext)).setOnClickListener(v->next());
        ((Button)findViewById(R.id.playerPrevious)).setOnClickListener(v->{if(PlaybackService.instance!=null&&PlaybackService.instance.isPrepared()&&PlaybackService.instance.getPlayer().getCurrentPosition()>3000)send("RESTART");else previous();});
        ((Button)findViewById(R.id.playerShuffle)).setOnClickListener(v->{shuffle=!shuffle;send("SHUFFLE");Toast.makeText(this,shuffle?"Shuffle on":"Shuffle off",Toast.LENGTH_SHORT).show();});
        ((Button)findViewById(R.id.playerRepeat)).setOnClickListener(v->{repeat=(repeat+1)%3;send("REPEAT");Toast.makeText(this,repeat==0?"Repeat off":repeat==1?"Repeat one":"Repeat all",Toast.LENGTH_SHORT).show();});
        ((Button)findViewById(R.id.playerQueue)).setOnClickListener(v->showQueue());
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onStartTrackingTouch(SeekBar s){dragging=true;}
            public void onProgressChanged(SeekBar s,int p,boolean user){}
            public void onStopTrackingTouch(SeekBar s){if(PlaybackService.instance!=null&&PlaybackService.instance.isPrepared())PlaybackService.instance.getPlayer().seekTo(s.getProgress());dragging=false;}
        });
    }
    private void playCurrent(){completionHandled=false;MediaItem m=queue.get(index);title.setText(m.title);artist.setText(m.artist);LibraryStore.addRecent(this,m);
        Intent i=new Intent(this,PlaybackService.class);i.setAction(PlaybackService.ACTION_PLAY);i.putExtra("uri",m.uri.toString());i.putExtra("title",m.title);i.putExtra("artist",m.artist);
        String[] uris=new String[queue.size()],titles=new String[queue.size()],artists=new String[queue.size()];
        for(int q=0;q<queue.size();q++){MediaItem item=queue.get(q);uris[q]=item.uri.toString();titles[q]=item.title;artists[q]=item.artist;}
        i.putExtra("queueUris",uris);i.putExtra("queueTitles",titles);i.putExtra("queueArtists",artists);i.putExtra("queueIndex",index);
        if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
    }
    private void send(String a){Intent i=new Intent(this,PlaybackService.class);i.setAction(a);if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}
    private void next(){if(shuffle&&queue.size()>1){int n;do{n=(int)(Math.random()*queue.size());}while(n==index);index=n;}else if(index+1<queue.size())index++;else if(repeat==2)index=0;else {if(PlaybackService.instance!=null)send("PAUSE");return;}playCurrent();}
    private void previous(){index=(index-1+queue.size())%queue.size();playCurrent();}
    private void showQueue(){String[] names=new String[queue.size()];for(int i=0;i<queue.size();i++)names[i]=queue.get(i).title;
        new android.app.AlertDialog.Builder(this).setTitle("Playback queue").setItems(names,(d,w)->{index=w;playCurrent();}).setNegativeButton("Close",null).show();}
    private String fmt(int ms){int sec=Math.max(0,ms/1000);return String.format(java.util.Locale.getDefault(),"%d:%02d",sec/60,sec%60);}
    @Override protected void onStart(){super.onStart();android.content.IntentFilter f=new android.content.IntentFilter(PlaybackService.ACTION_TRACK_CHANGED);if(android.os.Build.VERSION.SDK_INT>=33)registerReceiver(trackReceiver,f,android.content.Context.RECEIVER_NOT_EXPORTED);else registerReceiver(trackReceiver,f);}
    @Override protected void onStop(){try{unregisterReceiver(trackReceiver);}catch(Exception ignored){}super.onStop();}
    @Override protected void onResume(){super.onResume();handler.post(ticker);}
    @Override protected void onPause(){handler.removeCallbacks(ticker);super.onPause();}
}
