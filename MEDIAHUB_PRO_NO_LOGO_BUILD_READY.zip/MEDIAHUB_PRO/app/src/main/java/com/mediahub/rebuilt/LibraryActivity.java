package com.mediahub.rebuilt;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class LibraryActivity extends Activity {
    public static final int KIND_MUSIC=0, KIND_VIDEO=1, KIND_PHOTO=2;
    private int kind, sortMode=0;
    private List<MediaItem> all=new ArrayList<>(), shown=new ArrayList<>();
    private ArrayAdapter<MediaItem> adapter;
    private String saved;
    private static final int DELETE_REQUEST=771;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);setContentView(R.layout.activity_library);kind=getIntent().getIntExtra("kind",KIND_MUSIC);saved=getIntent().getStringExtra("saved");
        TextView heading=findViewById(R.id.libraryTitle);heading.setText(saved!=null?(saved.equals("favourites")?"Your favourites":"Recently played"):kind==0?"Music library":kind==1?"Video library":"Photo gallery");
        reload();ListView list=findViewById(R.id.mediaList);adapter=new MediaAdapter();list.setAdapter(adapter);
        list.setOnItemClickListener((p,v,pos,id)->open(shown.get(pos)));
        list.setOnItemLongClickListener((p,v,pos,id)->{showActions(shown.get(pos));return true;});
        EditText search=findViewById(R.id.searchField);search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){filter(s.toString());}public void afterTextChanged(Editable e){}});
        findViewById(R.id.sortButton).setOnClickListener(v->chooseSort());
        if(all.isEmpty())Toast.makeText(this,"No files found. Check media permission or connect your SD card folder from the home screen.",Toast.LENGTH_LONG).show();
    }

    private class MediaAdapter extends ArrayAdapter<MediaItem>{
        MediaAdapter(){super(LibraryActivity.this,0,shown);}
        @Override public android.view.View getView(int position,android.view.View convert,android.view.ViewGroup parent){
            android.view.View row=convert;if(row==null)row=getLayoutInflater().inflate(R.layout.row_media,parent,false);
            MediaItem item=getItem(position);((TextView)row.findViewById(R.id.rowTitle)).setText(item.title);
            String sub=item.artist==null||item.artist.trim().isEmpty()?item.mime:item.artist;
            ((TextView)row.findViewById(R.id.rowSubtitle)).setText(sub==null?"On this device":sub);
            ((TextView)row.findViewById(R.id.rowGlyph)).setText(kind==KIND_VIDEO?"▷":kind==KIND_PHOTO?"▧":"♫");return row;
        }
    }
    private void reload(){all=saved==null?MediaRepository.query(this,kind):LibraryStore.savedItems(this,saved);shown.clear();shown.addAll(all);sort();}
    private void filter(String q){shown.clear();String needle=q.toLowerCase(Locale.ROOT);for(MediaItem m:all)if(m.title.toLowerCase(Locale.ROOT).contains(needle)||(m.artist!=null&&m.artist.toLowerCase(Locale.ROOT).contains(needle)))shown.add(m);sort();if(adapter!=null)adapter.notifyDataSetChanged();}
    private void sort(){if(sortMode==0)Collections.sort(shown,(a,b)->a.title.compareToIgnoreCase(b.title));else if(sortMode==1)Collections.sort(shown,(a,b)->Long.compare(b.duration,a.duration));else Collections.reverse(shown);}
    private void chooseSort(){String[] choices={"Name (A–Z)","Duration (longest first)","Recently indexed"};new android.app.AlertDialog.Builder(this).setTitle("Sort files").setSingleChoiceItems(choices,sortMode,(d,w)->{sortMode=w;sort();adapter.notifyDataSetChanged();((TextView)findViewById(R.id.sortButton)).setText("SORT  ·  "+choices[w].toUpperCase(Locale.ROOT)+"     ⌄");d.dismiss();}).show();}
    private void open(MediaItem m){
        if(kind==KIND_MUSIC||saved!=null){Intent p=new Intent(this,PlayerActivity.class);p.putExtra("uri",m.uri.toString());startActivity(p);}
        else if(kind==KIND_VIDEO){Intent i=new Intent(this,VideoPlayerActivity.class);i.putExtra("uri",m.uri.toString());startActivity(i);}
        else{Intent i=new Intent(this,PhotoViewerActivity.class);i.putExtra("uri",m.uri.toString());startActivity(i);}
    }
    private void showActions(MediaItem m){
        ArrayList<String> actions=new ArrayList<>();actions.add(kind==KIND_PHOTO?"View photo":kind==KIND_VIDEO?"Play video":"Play");
        if(kind==KIND_MUSIC||saved!=null){actions.add(LibraryStore.isFavourite(this,m.uri.toString())?"Remove favourite":"Add to favourites");actions.add("Add to playlist");}
        actions.add("File information");
        if(android.os.Build.VERSION.SDK_INT>=30 && "media".equals(m.uri.getAuthority())) actions.add("Delete file from device");
        new android.app.AlertDialog.Builder(this).setTitle(m.title).setItems(actions.toArray(new String[0]),(d,w)->{
            String a=actions.get(w);if(a.startsWith("Play")||a.equals("View photo"))open(m);
            else if(a.contains("favourite")){if(LibraryStore.isFavourite(this,m.uri.toString()))LibraryStore.removeFavourite(this,m.uri.toString());else LibraryStore.addFavourite(this,m);Toast.makeText(this,"Favourites updated.",Toast.LENGTH_SHORT).show();}
            else if(a.equals("Add to playlist")){List<String> names=LibraryStore.names(this);if(names.isEmpty()){Toast.makeText(this,"Create a playlist first.",Toast.LENGTH_SHORT).show();return;}new android.app.AlertDialog.Builder(this).setItems(names.toArray(new String[0]),(x,pos)->{LibraryStore.addToPlaylist(this,names.get(pos),m);Toast.makeText(this,"Added to playlist.",Toast.LENGTH_SHORT).show();}).show();}
            else if(a.equals("File information")) new android.app.AlertDialog.Builder(this).setMessage("Name: "+m.title+"\nArtist: "+m.artist+"\nDuration: "+(m.duration/1000)+" seconds\nType: "+m.mime+"\nLocation: "+m.uri).setPositiveButton("OK",null).show();
            else if(a.equals("Delete file from device")) new android.app.AlertDialog.Builder(this).setMessage("Delete '"+m.title+"' from this device? Android will ask you to confirm.").setPositiveButton("Continue",(x,y)->deleteMedia(m)).setNegativeButton("Cancel",null).show();
        }).show();
    }
    private void deleteMedia(MediaItem item){
        if(android.os.Build.VERSION.SDK_INT<30)return;
        try{android.app.PendingIntent request=android.provider.MediaStore.createDeleteRequest(getContentResolver(),java.util.Collections.singletonList(item.uri));startIntentSenderForResult(request.getIntentSender(),DELETE_REQUEST,null,0,0,0);}
        catch(Exception e){Toast.makeText(this,"Android could not start the delete confirmation.",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==DELETE_REQUEST){if(resultCode==RESULT_OK){reload();if(adapter!=null)adapter.notifyDataSetChanged();Toast.makeText(this,"File deleted.",Toast.LENGTH_SHORT).show();}else Toast.makeText(this,"Deletion cancelled.",Toast.LENGTH_SHORT).show();}}
}
