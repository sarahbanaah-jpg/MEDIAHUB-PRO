package com.mediahub.rebuilt;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.widget.Toast;

/** Owns audio playback so it survives Activity changes and can advance the queue in background. */
public class PlaybackService extends Service {
    public static final String ACTION_PLAY="com.mediahub.rebuilt.PLAY";
    public static final String ACTION_TRACK_CHANGED="com.mediahub.rebuilt.TRACK_CHANGED";
    private static final String CHANNEL="media_playback";
    private static final int NOTIFICATION_ID=904;
    public static PlaybackService instance;
    private MediaPlayer player;
    private boolean prepared;
    private String[] queueUris=new String[0], queueTitles=new String[0], queueArtists=new String[0];
    private int queueIndex=0, repeatMode=0;
    private boolean shuffle=false;
    public MediaPlayer getPlayer(){return player;}
    public boolean isPrepared(){return prepared&&player!=null;}

    @Override public void onCreate(){super.onCreate();instance=this;createChannel();}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        String action=intent.getAction();
        if(ACTION_PLAY.equals(action)){
            String[] u=intent.getStringArrayExtra("queueUris");
            if(u!=null&&u.length>0){queueUris=u;queueTitles=intent.getStringArrayExtra("queueTitles");queueArtists=intent.getStringArrayExtra("queueArtists");queueIndex=Math.max(0,Math.min(intent.getIntExtra("queueIndex",0),queueUris.length-1));}
            else {queueUris=new String[]{intent.getStringExtra("uri")};queueTitles=new String[]{intent.getStringExtra("title")};queueArtists=new String[]{intent.getStringExtra("artist")};queueIndex=0;}
            playCurrent();
        } else if("TOGGLE".equals(action)){if(player!=null){if(player.isPlaying())player.pause();else if(prepared)player.start();updateNotification();}}
        else if("PAUSE".equals(action)){if(player!=null&&player.isPlaying()){player.pause();updateNotification();}}
        else if("RESUME".equals(action)){if(player!=null&&prepared&&!player.isPlaying()){player.start();updateNotification();}}
        else if("NEXT".equals(action))advance(false);
        else if("PREVIOUS".equals(action))advance(true);
        else if("REPEAT".equals(action)){repeatMode=(repeatMode+1)%3;}
        else if("SHUFFLE".equals(action)){shuffle=!shuffle;}
        else if("RESTART".equals(action)&&player!=null&&prepared)player.seekTo(0);
        return START_NOT_STICKY;
    }
    private void playCurrent(){
        if(queueUris.length==0||queueUris[queueIndex]==null)return;
        releasePlayer();final String uri=queueUris[queueIndex],title=safe(queueTitles,queueIndex,"Unknown track"),artist=safe(queueArtists,queueIndex,"Unknown artist");
        getSharedPreferences("now_playing",MODE_PRIVATE).edit().putString("uri",uri).putString("title",title).putString("artist",artist).putBoolean("playing",true).apply();
        Intent changed=new Intent(ACTION_TRACK_CHANGED).setPackage(getPackageName()).putExtra("uri",uri).putExtra("title",title).putExtra("artist",artist);sendBroadcast(changed);
        try{
            startForeground(NOTIFICATION_ID,buildNotification(title,artist,false));
            player=new MediaPlayer();player.setDataSource(this,Uri.parse(uri));
            player.setOnPreparedListener(mp->{prepared=true;mp.start();getSharedPreferences("now_playing",MODE_PRIVATE).edit().putBoolean("playing",true).apply();updateNotification();});
            player.setOnCompletionListener(mp->{if(repeatMode==1){mp.seekTo(0);mp.start();}else advance(false);});
            player.setOnErrorListener((mp,what,extra)->{prepared=false;advance(false);return true;});
            player.prepareAsync();
        }catch(Exception e){Toast.makeText(this,"Unable to play this audio file.",Toast.LENGTH_LONG).show();releasePlayer();stopForeground(true);stopSelf();}
    }
    private void advance(boolean backwards){
        if(queueUris.length==0)return;
        if(repeatMode==1&&!backwards){if(player!=null&&prepared){player.seekTo(0);player.start();}return;}
        if(shuffle&&queueUris.length>1){int next;do{next=(int)(Math.random()*queueUris.length);}while(next==queueIndex);queueIndex=next;}
        else if(backwards)queueIndex=(queueIndex-1+queueUris.length)%queueUris.length;
        else if(queueIndex+1<queueUris.length)queueIndex++;
        else if(repeatMode==2)queueIndex=0;
        else {getSharedPreferences("now_playing",MODE_PRIVATE).edit().putBoolean("playing",false).apply();if(player!=null&&player.isPlaying())player.pause();updateNotification();return;}
        playCurrent();
    }
    private String safe(String[] a,int i,String fallback){return a!=null&&i<a.length&&a[i]!=null&&!a[i].isEmpty()?a[i]:fallback;}
    private void updateNotification(){String t=getSharedPreferences("now_playing",MODE_PRIVATE).getString("title","MediaHub Pro"),a=getSharedPreferences("now_playing",MODE_PRIVATE).getString("artist","Local music");NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(nm!=null)nm.notify(NOTIFICATION_ID,buildNotification(t,a,player!=null&&player.isPlaying()));getSharedPreferences("now_playing",MODE_PRIVATE).edit().putBoolean("playing",player!=null&&player.isPlaying()).apply();}
    private PendingIntent action(String action,int request){Intent i=new Intent(this,PlaybackActionReceiver.class).setAction(action);return PendingIntent.getBroadcast(this,request,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    private Notification buildNotification(String title,String artist,boolean playing){
        Intent open=new Intent(this,MainActivity.class);PendingIntent content=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(title).setContentText(artist).setContentIntent(content).setOngoing(playing).setShowWhen(false)
          .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous,"Previous",action("PREVIOUS",1)).build())
          .addAction(new Notification.Action.Builder(playing?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play,playing?"Pause":"Play",action("TOGGLE",2)).build())
          .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next,"Next",action("NEXT",3)).build());
        if(Build.VERSION.SDK_INT>=21)b.setStyle(new Notification.MediaStyle().setShowActionsInCompactView(0,1,2));
        return b.build();
    }
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"MediaHub music playback",NotificationManager.IMPORTANCE_LOW);c.setDescription("Now playing and music controls");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    private void releasePlayer(){prepared=false;if(player!=null){try{player.setOnCompletionListener(null);if(player.isPlaying())player.stop();}catch(Exception ignored){}player.release();player=null;}}
    @Override public void onDestroy(){releasePlayer();getSharedPreferences("now_playing",MODE_PRIVATE).edit().putBoolean("playing",false).apply();stopForeground(true);instance=null;super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
