package com.mediahub.rebuilt;

import android.net.Uri;

public class MediaItem {
    public final long id;
    public final String title;
    public final String artist;
    public final Uri uri;
    public final long duration;
    public final String mime;
    public MediaItem(long id, String title, String artist, Uri uri, long duration, String mime) {
        this.id=id; this.title=title; this.artist=artist; this.uri=uri; this.duration=duration; this.mime=mime;
    }
    @Override public String toString() { return title + (artist == null || artist.isEmpty() ? "" : "\n" + artist); }
}
