package com.mediahub.rebuilt;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.widget.VideoView;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.Toast;

public class VideoPlayerActivity extends Activity {
    private VideoView video;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_video);
        video=findViewById(R.id.videoView);
        String raw=getIntent().getStringExtra("uri");
        if(raw==null){finish();return;}
        video.setVideoURI(Uri.parse(raw));
        video.setMediaController(new MediaController(this));
        video.setOnErrorListener((mp,what,extra)->{Toast.makeText(this,"This video cannot be played.",Toast.LENGTH_LONG).show();finish();return true;});
        video.setOnPreparedListener(mp->video.start());
        ((Button)findViewById(R.id.playButton)).setOnClickListener(v->{if(video.isPlaying())video.pause();else video.start();});
        ((Button)findViewById(R.id.rewindButton)).setOnClickListener(v->video.seekTo(Math.max(0,video.getCurrentPosition()-10000)));
        ((Button)findViewById(R.id.forwardButton)).setOnClickListener(v->video.seekTo(Math.min(video.getDuration(),video.getCurrentPosition()+10000)));
    }
    @Override protected void onPause(){if(video!=null&&video.isPlaying())video.pause();super.onPause();}
}
