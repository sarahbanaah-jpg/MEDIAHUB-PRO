# MEDIAHUB PRO (no-logo build)

Native Android media player project using Java and the Android SDK.

## Project details
- Application ID: `com.mediahub.rebuilt`
- Version: `2.0` (version code `2`)
- Minimum Android: 6.0 (API 23)
- Target SDK: 34
- Compile SDK: 35
- Android Gradle Plugin: 8.6.1 (requires Gradle 8.7 and JDK 17)

## Build an APK in CodeAssist
1. Extract this ZIP.
2. Open the `MEDIAHUB_PRO` folder (the folder containing `settings.gradle`) in CodeAssist.
3. Allow Gradle sync and install any SDK platform/build-tools packages CodeAssist requests.
4. Run the `assembleDebug` task.
5. The debug APK should be at `app/build/outputs/apk/debug/app-debug.apk`.

## Build an APK with GitHub Actions
The included workflow `.github/workflows/android-build.yml` builds a debug APK on pushes to `main`, pull requests, or a manual workflow run. When the workflow succeeds, download `MEDIAHUB-PRO-debug-apk` from the run's **Artifacts** section.

## Important release notes
- A debug APK is signed with a debug key and is suitable for testing, not as a production update for an existing release signed with a different key.
- For in-place APK updates, every release must use the same application ID and the same private signing key. Keep that key private and backed up; never commit it to GitHub.
- Android will show its package-installer confirmation for sideloaded APK updates. The app cannot silently install its own update.
- This project has not yet passed an Android SDK build in this environment. The first successful CodeAssist or GitHub Actions build is required before calling the APK verified.
